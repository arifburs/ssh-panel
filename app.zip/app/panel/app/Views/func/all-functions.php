<div id="testLoad"></div>

<br />
<div id="result"></div>


<div id="demo">
<button type="button" onclick="loadDoc()">Change Content</button>
</div>



<?php
function convert($size)
 {
    $unit=array(' b',' KB',' MB',' GB',' TB',' PB');
    return @round($size/pow(1024,($i=floor(log($size,1024)))),2).' '.$unit[$i];
 }

echo convert(memory_get_usage(true)); // 123 kb
?>
<?= 

	print ini_get('disable_functions'); 
	print memory_get_usage() . "\n";

?>
<?php

    function echo_memory_usage() {

        $mem_usage = memory_get_usage(true);

        

        if ($mem_usage < 1024)

            echo $mem_usage." B";

        elseif ($mem_usage < 1048576)

            echo round($mem_usage/1024,2)." KB";

        else

            echo round($mem_usage/1048576,2)." MB";

            

        echo "<br/>";

    }
?>

<br/>

<?=

	
	echo_memory_usage();

?>

<br/>

<!--?=

$.ajax({ url: 'secondpage.php',
	data: {'q': data},
	type: 'post',
	success: function(output) {
                    //some code
}
?-->

<br/>




<div class="container">
  <div class="row">
    <div class="col-md-12">
	    <p>&nbsp;</p>
		<p>&nbsp;</p>
		<button type="button" id="button1"  class="btn btn-success btn-block">Click Here To Start Progress Bar</button>
		<p>&nbsp;<p>
		<button type="button" id="button2"  class="btn btn-danger btn-block">Click Here To Stop Progress Bar</button>
    </div>
    <div class="col-md-12">
		<p>&nbsp;</p>
	    <p>&nbsp;</p>
		<div id="progressbar" class="border:1px solid var(--so-input-border);background:var(--so-input-back);border-radius:0.25rem;"></div>
  
		<!-- Progress information -->
		<br>
		<div id="information"></div>
	</div>
  </div>
</div>

<iframe id="loadarea" style="display:none;"></iframe><br />

<script >
	$("#button1").click(function(){
		document.getElementById('loadarea').src = 'app/Views/settings/progressbar.php';
	});
	$("#button2").click(function(){
		document.getElementById('loadarea').src = '';
	});
</script>

<br/>

<!--?= 
function rutime($ru, $rus, $index){
 return ($ru["ru_$index.tv_sec"]*1000 + intval($ru["ru_$index.tv_usec"]/1000)) - ($rus["ru_$index.tv_sec"]*1000 + intval($rus["ru_$index.tv_usec"]/1000));
}

//$cpu_before = getrusage();

//$cpu_after = getrusage();
//print "<div>Took ".rutime($cpu_after, $cpu_before, "utime")." ms CPU usage</div>";



?-->













<!--script>
$(document).ready(function(){
	// Progress Bar CPU
	var cpuData = "<--?php $cpuData['loadAvg'] ?>" * 1.98 - 100
	var cpu = 100 - cpuData
	$('#testLoad').text(cpu);
});
</script-->

<!--script>
			function start(){
				$.ajax({
					async:true,
					type:"POST",
					url: 'app/Views/users/progress.php',
					success: function(result) {
						var hasil=parseInt(result)+0;
						var value = $('#result').progressbar('getValue');
						if(value < 100) {
							value += hasil * 10;
							$('#result').progressbar('setValue', value);
						}
					}
				});
			};
    </script-->






<script>
$(document).ready(function(){
	setInterval(function(){
		$("#testLoad").load('app/Views/pages/progress.php');

	//var cpuData = "<?= $ramNum = 100 - (($ramData['usage_percent'] * 1.9) - 100) ?>"
	//$('#demo').html(cpuData);
	
	}, 2000);
});

</script>

<p id="results"></p>
<input type="text" id="UserName" placeholder="نام شما در اینجا">
<input type="text" id="UserEmail" placeholder="ایمیل شما در اینجا">
<button type="button" onclick="MyLoad();">ارسال</button>
<p id="Result"></p>



<script>
//function periodicalRequest() {
//	var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
	
//	xhr.open("GET", "app/Views/users/progs.php", true);
//	xhr.onreadystatechange = function(){
//		if (xhr.readyState == 4) {
//			if (xhr.status == 200) {
//				document.getElementById("results").innerHTML = xhr.responseText;
//			}
//		}
//	};
//	xhr.send(null);
//};

//window.onload = function() {
//	window.setInterval(periodicalRequest, 2000);
//}









//	setInterval(function() {
//		$("#testLoad").load(location.href + " #testLoad");
//	}, 2000);
</script>

<script>$(document).ready(function(){ setInterval(function(){ $("#testLoad").load('app/Views/settings/testLoad.php'); }, 2000); });</script>

<script src="app/Views/settings/jquery.progressbar.js"></script>
<table>
	<tr>
		<td style="font-family:verdana">SLA</td>
	</tr>
	<tr>
		<td id="sla-bar" style="height:<?= $cpuData["loadAvg"] ?>;font-family:verdana">Inicializando...</td>
	</tr>
</table>
<script>
	$(document).ready(function() {
		$("#sla-bar").pb({ url: "app/Views/settings/sla.php"});
	});
</script>



<br />

<?= $cpuData["loadAvg"] ?>
<br />
<?= $ramData['usage_percent'] ?>
<br />
<div id="progress" class="" style="border:1px solid var(--so-input-border);background:var(--so-input-back);border-radius:0.25rem;height:40px;width:<?= $cpuData['loadAvg'] ?>%"></div>