// Progress Bar RAM
	var ramData = "<?= $ramData['usage_percent'] ?>" * 1.98 - 100
	var ram = 100 - ramData
	$('#ramProgress').find('#ramLine').animate({
		'stroke-dashoffset': ram
	}, 500)

	// Progress Bar CPU
	var cpuData = "<?= $cpuData['loadAvg'] ?>" * 1.98 - 100
	var cpu = 100 - cpuData
	$('#cpuProgress').find('#cpuLine').animate({
		'stroke-dashoffset': cpu
	}, 500)

	// Progress Bar Disk
	var hddData = "<?= $diskData['usage_percent'] ?>" * 1.98 - 100
	var hdd = 100 - hddData
	$('#hddProgress').find('#hddLine').animate({
		'stroke-dashoffset': hdd
	}, 500)
	
	// Mobile Slider
	slidesPerView: 1,
	//spaceBetween: 30,
	//loop: true,
	//pagination: {
	//	el: '.swiper-pagination',
	//},