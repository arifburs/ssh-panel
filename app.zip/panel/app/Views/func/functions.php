<div id="testLoad"></div>
<script>$(document).ready(function(){ setInterval(function(){ $("#testLoad").load('app/Views/func/pro.php'); }, 2000); });</script>