<?php 
/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

if (!defined('PATH')) die();


$configs['logger']['enabled'] = true;
$configs['logger']['name'] = '';
$configs['logger']['addr'] = '';
?>
