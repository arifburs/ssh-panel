<?php
/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

if (!defined('PATH')) die();

if (getConfig('session', 'enabled')) {
  $container['session'] = function ($c) {
    return new \SlimSession\Helper;
  };
}
